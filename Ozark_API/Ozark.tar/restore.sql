--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ozark;
--
-- Name: ozark; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ozark WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE ozark OWNER TO postgres;

\connect ozark

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: actor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.actor (
    actor_id character varying(3) NOT NULL,
    first_name character varying,
    last_name character varying,
    middle_name character varying
);


ALTER TABLE public.actor OWNER TO postgres;

--
-- Name: actor_episode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.actor_episode (
    actor_id character varying NOT NULL,
    episode_id character varying NOT NULL
);


ALTER TABLE public.actor_episode OWNER TO postgres;

--
-- Name: character; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."character" (
    char_id character varying(3) NOT NULL,
    first_name character varying,
    last_name character varying,
    actor_id character varying(3) NOT NULL
);


ALTER TABLE public."character" OWNER TO postgres;

--
-- Name: episode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.episode (
    episode_id character varying NOT NULL,
    episode_num integer,
    title character varying,
    release_date timestamp without time zone,
    imdb_rating double precision,
    director character varying,
    synopsis character varying,
    season_id character varying(2)
);


ALTER TABLE public.episode OWNER TO postgres;

--
-- Name: season; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.season (
    season_id character varying NOT NULL,
    season integer NOT NULL
);


ALTER TABLE public.season OWNER TO postgres;

--
-- Data for Name: actor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.actor (actor_id, first_name, last_name, middle_name) FROM stdin;
\.
COPY public.actor (actor_id, first_name, last_name, middle_name) FROM '$$PATH$$/3016.dat';

--
-- Data for Name: actor_episode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.actor_episode (actor_id, episode_id) FROM stdin;
\.
COPY public.actor_episode (actor_id, episode_id) FROM '$$PATH$$/3019.dat';

--
-- Data for Name: character; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."character" (char_id, first_name, last_name, actor_id) FROM stdin;
\.
COPY public."character" (char_id, first_name, last_name, actor_id) FROM '$$PATH$$/3018.dat';

--
-- Data for Name: episode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.episode (episode_id, episode_num, title, release_date, imdb_rating, director, synopsis, season_id) FROM stdin;
\.
COPY public.episode (episode_id, episode_num, title, release_date, imdb_rating, director, synopsis, season_id) FROM '$$PATH$$/3017.dat';

--
-- Data for Name: season; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.season (season_id, season) FROM stdin;
\.
COPY public.season (season_id, season) FROM '$$PATH$$/3015.dat';

--
-- Name: actor_episode actor_episode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actor_episode
    ADD CONSTRAINT actor_episode_pkey PRIMARY KEY (actor_id, episode_id);


--
-- Name: actor actor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actor
    ADD CONSTRAINT actor_pkey PRIMARY KEY (actor_id);


--
-- Name: character character_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT character_pkey PRIMARY KEY (char_id);


--
-- Name: episode episode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.episode
    ADD CONSTRAINT episode_pkey PRIMARY KEY (episode_id);


--
-- Name: season season_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season
    ADD CONSTRAINT season_pkey PRIMARY KEY (season_id);


--
-- Name: season season_season_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season
    ADD CONSTRAINT season_season_key UNIQUE (season);


--
-- Name: actor_episode actor_episode_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actor_episode
    ADD CONSTRAINT actor_episode_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.actor(actor_id);


--
-- Name: actor_episode actor_episode_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.actor_episode
    ADD CONSTRAINT actor_episode_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episode(episode_id);


--
-- Name: character character_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."character"
    ADD CONSTRAINT character_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.actor(actor_id);


--
-- Name: episode episode_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.episode
    ADD CONSTRAINT episode_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.season(season_id);


--
-- PostgreSQL database dump complete
--

